# RecipeBook — 10-апта

9-аптадағы HTML/CSS/JS интерфейсі PHP беттеріне көшірілді. Дизайн сақталды.

## Файлдар
- `index.php` — басты бет
- `recipes.php` — рецептілер және GET іздеу параметрлері
- `login.php`, `register.php` — POST формалар
- `includes/header.php`, `includes/footer.php` — ортақ интерфейс
- `includes/form_handler.php` — серверлік валидация
- `style.css`, `script.js` — 9-аптадағы дизайн және карточкалар

## Іске қосу (XAMPP)
1. Архивтегі `RecipeBook_10week` қалтасын `C:\xampp\htdocs\` ішіне көшіріңіз.
2. XAMPP Control Panel → Apache → Start.
3. Браузерге `http://localhost/RecipeBook_10week/` енгізіңіз.
4. `recipes.php` бетінде іздеу мен санат сүзгісін тексеріңіз.
5. `register.php` және `login.php` беттерінде форманы жіберіп, серверлік хабарламаны тексеріңіз.

**Ескерту:** 10-аптада дерекқор мен шынайы аутентификация әлі жоқ. Олар 11-аптада қосылады. Рецепт карточкалары әзірге JavaScript массивінен көрсетіледі.
