const recipes=[{name:'Бауырсақ',category:'Ұлттық тағам',time:'45 минут',img:'https://images.unsplash.com/photo-1509440159596-0249088772ff?w=900'},{name:'Көкөніс салаты',category:'Салат',time:'15 минут',img:'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=900'},{name:'Құймақ',category:'Таңғы ас',time:'25 минут',img:'https://images.unsplash.com/photo-1528207776546-365bb710ee93?w=900'},{name:'Тауық еті',category:'Негізгі тағам',time:'50 минут',img:'https://images.unsplash.com/photo-1532550907401-a500c9a57435?w=900'},{name:'Паста',category:'Негізгі тағам',time:'30 минут',img:'https://images.unsplash.com/photo-1473093295043-cdd812d0e601?w=900'},{name:'Жеміс десерті',category:'Десерт',time:'20 минут',img:'https://images.unsplash.com/photo-1490474418585-ba9bad8fd0ea?w=900'}];
function renderRecipes(items,target='recipe-grid'){const el=document.getElementById(target);if(!el)return;el.innerHTML=items.length?items.map(r=>`<article class="recipe"><img src="${r.img}" alt="${r.name}"><div class="content"><span class="tag">${r.category}</span><h3>${r.name}</h3><p class="muted">⏱ ${r.time}</p><a class="btn" href="recipes.html">Қарау</a></div></article>`).join(''):'<p>Рецепт табылмады.</p>'}function filterRecipes(){const q=document.getElementById('search')?.value.toLocaleLowerCase('kk')||'';const c=document.getElementById('category')?.value||'';renderRecipes(recipes.filter(r=>r.name.toLocaleLowerCase('kk').includes(q)&&(!c||r.category===c)))}document.addEventListener('DOMContentLoaded',()=>{
  renderRecipes(document.body.dataset.page==='home'?recipes.slice(0,3):recipes);
  const params = new URLSearchParams(window.location.search);
  const search = document.getElementById('search');
  const category = document.getElementById('category');
  if (search && params.has('q')) search.value = params.get('q').slice(0,100);
  if (category && params.has('category')) category.value = params.get('category');
  if (search || category) filterRecipes();
  search?.addEventListener('input', filterRecipes);
  category?.addEventListener('change', filterRecipes);
});
