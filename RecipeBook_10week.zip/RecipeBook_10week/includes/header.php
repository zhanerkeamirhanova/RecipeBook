<?php
if (!isset($pageTitle)) $pageTitle = 'RecipeBook';
if (!isset($pageName)) $pageName = '';
?>
<!doctype html>
<html lang="kk">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8') ?></title>
  <link rel="stylesheet" href="style.css">
</head>
<body<?= $pageName ? ' data-page="'.htmlspecialchars($pageName, ENT_QUOTES, 'UTF-8').'"' : '' ?>>
<header>
  <div class="nav">
    <a class="logo" href="index.php">🍃 RecipeBook</a>
    <nav>
      <a href="index.php">Басты бет</a>
      <a href="recipes.php">Рецептілер</a>
      <a href="login.php">Кіру / Тіркелу</a>
    </nav>
  </div>
</header>
