<footer>© 2026 RecipeBook — Рецептілер жинағы</footer>
<script src="script.js"></script>
</body>
</html>
