<?php
// 10-апта: форманы серверде тексеру; дерекқорға сақтау 11-аптада қосылады.
$error = '';
$success = '';
$name = '';
$email = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim((string)($_POST['name'] ?? ''));
    $email = trim((string)($_POST['email'] ?? ''));
    $password = (string)($_POST['password'] ?? '');
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 190) {
        $error = 'Электрондық пошта дұрыс енгізілмеген.';
    } elseif (strlen($password) < 6) {
        $error = 'Құпиясөз кемінде 6 таңбадан тұруы керек.';
    } elseif ($formMode === 'register' && (mb_strlen($name) < 2 || mb_strlen($name) > 80)) {
        $error = 'Аты-жөні 2–80 таңба аралығында болуы керек.';
    } else {
        $success = 'Форма серверде тексерілді. Аккаунтты сақтау және кіру 11-аптада іске қосылады.';
    }
}
