<?php
$pageTitle = 'RecipeBook — Басты бет';
$pageName = 'home';
require __DIR__ . '/includes/header.php';
?>
<main><section class="hero"><div><h1>Дәмді тағамдар әлеміне қош келдіңіз!</h1><p>Күнделікті ас мәзіріне арналған қарапайым әрі дәмді рецептілерді бір жерден табыңыз.</p><a class="btn" href="recipes.php">Рецептілерді көру</a></div><img alt="Дәмді тағам" src="https://images.unsplash.com/photo-1547592180-85f173990554?w=1000"/></section><h2 class="section-title">Танымал рецептілер</h2><div class="grid" id="recipe-grid"></div></main>
<?php require __DIR__ . '/includes/footer.php'; ?>
