<?php
$pageTitle = 'RecipeBook — Рецептілер';
$pageName = 'recipes';
// GET параметрлерін серверде оқу және шектеу.
$query = trim((string)($_GET['q'] ?? ''));
if (mb_strlen($query) > 100) $query = mb_substr($query, 0, 100);
$category = trim((string)($_GET['category'] ?? ''));
require __DIR__ . '/includes/header.php';
?>
<main><h1>Барлық рецептілер</h1><p class="muted">Өзіңізге ұнайтын тағамды тауып көріңіз.</p><form class="searchbar" method="get" action="recipes.php"><input id="search" placeholder="Рецепт атауын іздеу..." type="search"/><select id="category" name="category"><option value="">Барлық санаттар</option><option>Ұлттық тағам</option><option>Салат</option><option>Таңғы ас</option><option>Негізгі тағам</option><option>Десерт</option></select><button class="btn" type="submit">Іздеу</button></form><div class="grid" id="recipe-grid"></div></main>
<?php require __DIR__ . '/includes/footer.php'; ?>
