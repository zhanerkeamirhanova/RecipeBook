<?php
$pageTitle = 'RecipeBook — Тіркелу';
$formMode = 'register';
require __DIR__ . '/includes/form_handler.php';
require __DIR__ . '/includes/header.php';
?>
<main><div class="form-card"><h1>Жаңа аккаунт ашу</h1><?php if ($error): ?><p class="server-message error"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></p><?php endif; ?>
<?php if ($success): ?><p class="server-message success"><?= htmlspecialchars($success, ENT_QUOTES, 'UTF-8') ?></p><?php endif; ?>
<form action="register.php" method="post"><label for="name">Аты-жөні</label><input id="name" name="name" required=""/><label for="email">Электрондық пошта</label><input id="email" name="email" required="" type="email"/><label for="password">Құпиясөз</label><input id="password" minlength="6" name="password" required="" type="password"/><button class="btn" type="submit">Тіркелу</button></form><p>Аккаунтыңыз бар ма? <a href="login.php">Кіру</a></p></div></main>
<?php require __DIR__ . '/includes/footer.php'; ?>
