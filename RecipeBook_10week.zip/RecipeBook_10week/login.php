<?php
$pageTitle = 'RecipeBook — Кіру';
$formMode = 'login';
require __DIR__ . '/includes/form_handler.php';
require __DIR__ . '/includes/header.php';
?>
<main><div class="form-card"><h1>Жеке кабинетке кіру</h1><?php if ($error): ?><p class="server-message error"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></p><?php endif; ?>
<?php if ($success): ?><p class="server-message success"><?= htmlspecialchars($success, ENT_QUOTES, 'UTF-8') ?></p><?php endif; ?>
<form action="login.php" method="post"><label for="email">Электрондық пошта</label><input id="email" name="email" placeholder="example@mail.com" required="" type="email"/><label for="password">Құпиясөз</label><input id="password" minlength="6" name="password" required="" type="password"/><button class="btn" type="submit">Кіру</button></form><p>Аккаунтыңыз жоқ па? <a href="register.php">Тіркелу</a></p></div></main>
<?php require __DIR__ . '/includes/footer.php'; ?>
